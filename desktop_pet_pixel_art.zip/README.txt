PET VIRTUAL - VERSAO PIXEL ART

Estrutura:
  desktop_pet.py
  assets/personagem/frente.png
  assets/personagem/lado.png
  assets/personagem/diagonal.png
  assets/personagem/costas.png

Como instalar:
  pip install --break-system-packages Pillow python-xlib
  sudo apt install python3-tk

Como executar:
  cd /caminho/para/pet_adapt
  python3 desktop_pet.py

A personagem agora usa sprites PNG em pixel art.
- andando: usa principalmente lado e espelha para esquerda/direita
- virando: passa por diagonal e frente
- em outro momento do ciclo: mostra costas
- sendo arrastada: diagonal
- sentada: frente

Se quiser trocar a arte, substitua os quatro PNGs mantendo os mesmos nomes.
O programa usa NEAREST para preservar os pixels.
