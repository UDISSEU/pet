#!/usr/bin/env python3
"""
Bichinho de Desktop (menina anime/cartoon) + IA local (Ollama)
-------------------------------------------------------------------
Personagem pixel art em sprites 2D, com quatro ângulos (frente, lado, diagonal e costas).

Ela observa (sem mexer em nada) os apps que você tem aberto, comenta
quando percebe que você tá no YouTube, senta cansada em cima de
janelas abertas de vez em quando, balança feito num carro em
movimento quando você arrasta ela com o mouse, e levanta se a janela
em que estava sentada for fechada.

DEPENDÊNCIAS:
    pip install --break-system-packages Pillow python-xlib
    sudo apt install python3-tk

- Pillow: obrigatório.
- python-xlib: opcional. Sem ela, ela ainda funciona (anda, fala,
  responde), só perde a transparência real, observar apps e sentar
  em janelas — cai tudo graciosamente sem travar.

Como rodar:
    python3 desktop_pet.py

Como usar:
    Clique e segure       -> pega ela, arrasta rápido pra ver o balanço "de carro"
    Soltar o clique         -> ela volta ao normal
    Clique simples (sem arrastar) -> fecha o balão de fala mais cedo
    Duplo clique             -> abre o claude.ai no navegador
    Clique direito             -> menu (perguntar / falar algo / esquecer conversa / fechar)
"""

import json
import math
import os
import random
import re
import threading
import tkinter as tk
import urllib.error
import urllib.request
import webbrowser
from io import BytesIO
from pathlib import Path
from tkinter import messagebox, simpledialog

try:
    from PIL import Image, ImageDraw, ImageFont, ImageTk
except ImportError:
    import sys
    print("Falta a biblioteca Pillow. Instale com:\n"
          "    pip install --break-system-packages Pillow", file=sys.stderr)
    sys.exit(1)

try:
    from Xlib import X, display as xlib_display
    from Xlib.ext import shape as xlib_shape
    XLIB_AVAILABLE = True
except ImportError:
    XLIB_AVAILABLE = False


# ---------------------------------------------------------------------------
# Configuração
# ---------------------------------------------------------------------------
WIDTH = 140
BASE_HEIGHT = 190
SCREEN_MARGIN = 40
SCALE = 3
TICK_MS = 40

# ---------------------------------------------------------------------------
# Personagem em pixel art
# ---------------------------------------------------------------------------
ASSET_DIR = Path(__file__).resolve().parent / "assets" / "personagem"
SPRITE_MAX_W = 124
SPRITE_MAX_H = 176
SPRITE_RESAMPLE = Image.Resampling.NEAREST

SPEECH_LINES = [
    "Oi!",
    "Precisa de algo?",
    "Bora codar?",
    "Estudando hoje?",
    "Clica com o botão direito pra me perguntar algo",
    "Analista de dados on!",
    ":)",
]

APP_COMMENTS = {
    "youtube": [
        "Rindo do vídeo ou é sério isso?",
        "Mais um vídeo pra 'só um rapidinho', né?",
        "O algoritmo te pegou de novo",
        "Assistindo ou trabalhando? 👀",
    ],
    "firefox": ["Navegando por aí?", "Achou algo legal?"],
    "chrome": ["Navegando por aí?", "Muitas abas hein"],
    "chromium": ["Navegando por aí?"],
    "code": ["Bora codar!", "Código novo?"],
    "sublime": ["Editando código?"],
    "terminal": ["Modo terminal ativado", "Linha de comando é vida"],
    "xterm": ["Modo terminal ativado"],
    "thunar": ["Organizando arquivos?"],
    "nautilus": ["Organizando arquivos?"],
    "files": ["Vendo seus arquivos?"],
    "libreoffice": ["Trabalhando em documento?"],
    "gimp": ["Editando imagem, bonito!"],
    "spotify": ["Boa música?"],
}
GENERIC_COMMENTS = ["Vendo o que você tá fazendo", "Te acompanhando por aqui", ":)"]
SIT_DOWN_LINES = ["Ufa... só um descansinho", "Cansei de andar por aí", "Cadeira improvisada, hihi"]
STAND_CLOSED_LINES = ["Ei, sumiu minha cadeira!", "A janela fechou, levantando!"]
STAND_TIMEOUT_LINES = ["Descanso acabou, vamo lá de novo"]

OLLAMA_URL = "http://localhost:11434/api/chat"
OLLAMA_MODEL = "llama3.2:1b"

HISTORY_PATH = Path.home() / ".desktop_pet_history.json"
MAX_HISTORY_MESSAGES = 12

SYSTEM_PROMPT = (
    "Você é a companheira de desktop do Ulisses. Responda de forma curta, "
    "calorosa e direta, sem enrolação. Se não souber algo, diga isso "
    "abertamente em vez de inventar. Respostas de no máximo 3 ou 4 frases."
)

# Paleta anime/cartoon (personagem original, estilo "boneca pixel art" com
# sombreado em camadas, inspirada em cabelo longo ondulado + jaqueta oversized)
COL_HAIR = (94, 62, 45, 255)            # castanho
COL_HAIR_LIGHT = (128, 88, 62, 255)     # mecha clara (volume)
COL_HAIR_DARK = (64, 40, 28, 255)       # sombra do cabelo
COL_SKIN = (255, 219, 191, 255)
COL_SKIN_SHADOW = (232, 190, 160, 255)
COL_JACKET = (40, 38, 46, 255)          # jaqueta preta oversized
COL_JACKET_DARK = (24, 22, 28, 255)
COL_SHIRT = (215, 215, 220, 255)        # blusa cinza-clara por baixo
COL_JEANS = (150, 176, 205, 255)        # calça jeans larga
COL_JEANS_DARK = (110, 135, 165, 255)
COL_BLUSH = (255, 150, 170, 170)
COL_EYE = (35, 28, 24, 255)             # olhos bem escuros
COL_SHOE = (35, 33, 38, 255)            # tênis preto


def get_font(size):
    for path in (
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    ):
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            continue
    return ImageFont.load_default()


FONT_BUBBLE = get_font(13 * SCALE)
FONT_SMALL = get_font(9 * SCALE)


# ---------------------------------------------------------------------------
# IA local (Ollama)
# ---------------------------------------------------------------------------
def load_history():
    if HISTORY_PATH.exists():
        try:
            return json.loads(HISTORY_PATH.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return []
    return []


def save_history(history):
    try:
        HISTORY_PATH.write_text(json.dumps(history, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        pass


def ask_local_ai(history):
    messages = [{"role": "system", "content": SYSTEM_PROMPT}] + history
    payload = json.dumps({"model": OLLAMA_MODEL, "messages": messages, "stream": False}).encode("utf-8")
    req = urllib.request.Request(OLLAMA_URL, data=payload,
                                  headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.URLError:
        return ("Não consegui falar com o Ollama. Confirme que ele está rodando "
                f"e que o modelo '{OLLAMA_MODEL}' foi baixado (ollama pull {OLLAMA_MODEL}).")
    except urllib.error.HTTPError as e:
        return f"Erro {e.code} do Ollama: {e.read().decode('utf-8', errors='ignore')[:200]}"
    return data.get("message", {}).get("content", "").strip() or "(resposta vazia)"


# ---------------------------------------------------------------------------
# Integração opcional com X11
# ---------------------------------------------------------------------------
class X11Helper:
    def __init__(self):
        self.ok = False
        self.last_shape_error = None
        self.dpy = None
        self.root_win = None
        if not XLIB_AVAILABLE:
            return
        try:
            self.dpy = xlib_display.Display()
            self.root_win = self.dpy.screen().root
            self.ok = True
        except Exception:
            self.ok = False

    def get_active_window_info(self):
        if not self.ok:
            return None
        try:
            NET_ACTIVE = self.dpy.intern_atom("_NET_ACTIVE_WINDOW")
            prop = self.root_win.get_full_property(NET_ACTIVE, X.AnyPropertyType)
            if not prop or not prop.value or not prop.value[0]:
                return None
            win = self.dpy.create_resource_object("window", prop.value[0])
            wm_class = win.get_wm_class()
            klass = wm_class[1].lower() if wm_class else ""
            name = (win.get_wm_name() or "")
            return klass, name
        except Exception:
            return None

    def get_open_windows(self, exclude_win_id=None):
        """Lista janelas 'de verdade' abertas, com posição/tamanho na tela."""
        if not self.ok:
            return []
        try:
            NET_LIST = self.dpy.intern_atom("_NET_CLIENT_LIST")
            prop = self.root_win.get_full_property(NET_LIST, X.AnyPropertyType)
            if not prop or not prop.value:
                return []
            results = []
            for win_id in prop.value:
                if win_id == exclude_win_id:
                    continue
                try:
                    win = self.dpy.create_resource_object("window", win_id)
                    geom = win.get_geometry()
                    coords = win.translate_coords(self.root_win, 0, 0)
                    rx = -coords.x
                    ry = -coords.y
                    w, h = geom.width, geom.height
                    if w < 200 or h < 150:
                        continue  # ignora painéis, docks, coisas pequenas
                    results.append({"id": win_id, "x": rx, "y": ry, "w": w, "h": h})
                except Exception:
                    continue
            return results
        except Exception:
            return []

    def window_exists(self, win_id):
        if not self.ok:
            return False
        try:
            NET_LIST = self.dpy.intern_atom("_NET_CLIENT_LIST")
            prop = self.root_win.get_full_property(NET_LIST, X.AnyPropertyType)
            return bool(prop and prop.value and win_id in list(prop.value))
        except Exception:
            return False

    def apply_shape_mask(self, tk_window_id, pil_rgba_image):
        if not self.ok:
            return False
        try:
            bit_order = self.dpy.info.bitmap_format_bit_order

            alpha = pil_rgba_image.split()[3]
            mask_img = alpha.point(lambda p: 255 if p > 20 else 0).convert("1")

            buf = BytesIO()
            mask_img.save(buf, format="XBM")  # XBM já usa ordem LSBFirst por padrão
            xbm_text = buf.getvalue().decode("ascii", errors="ignore")
            hex_bytes = re.findall(r"0x([0-9a-fA-F]{2})", xbm_text)
            if not hex_bytes:
                return False
            raw = [int(h, 16) for h in hex_bytes]
            if bit_order != X.LSBFirst:
                raw = [int(f"{b:08b}"[::-1], 2) for b in raw]  # servidor usa MSBFirst
            data = bytes(raw)

            width, height = mask_img.size
            win = self.dpy.create_resource_object("window", tk_window_id)
            pixmap = win.create_pixmap(width, height, 1)
            gc = pixmap.create_gc(foreground=1, background=0)
            pixmap.put_image(gc, 0, 0, width, height, X.XYBitmap, 1, 0, data)

            xlib_shape.combine(win, xlib_shape.SO.Set, xlib_shape.SK.Bounding, 0, 0, pixmap)
            xlib_shape.combine(win, xlib_shape.SO.Set, xlib_shape.SK.Input, 0, 0, pixmap)

            gc.free()
            pixmap.free()
            self.dpy.sync()
            return True
        except Exception as exc:
            self.last_shape_error = f"{type(exc).__name__}: {exc}"
            return False


# ---------------------------------------------------------------------------
# Personagem
# ---------------------------------------------------------------------------
class DesktopPet:
    def __init__(self):
        self.history = load_history()
        self.x11 = X11Helper()
        self.shape_supported = None

        self.root = tk.Tk()
        self.root.overrideredirect(True)
        self.root.wm_attributes("-topmost", True)
        try:
            self.root.wm_attributes("-type", "splash")
        except tk.TclError:
            pass

        self.screen_w = self.root.winfo_screenwidth()
        self.screen_h = self.root.winfo_screenheight()

        self.x = float(random.randint(100, max(101, self.screen_w - 200)))
        self.y = float(self.screen_h - BASE_HEIGHT - SCREEN_MARGIN)
        self.cur_height = BASE_HEIGHT
        self.prev_x = self.x

        self.label = tk.Label(self.root, bd=0, highlightthickness=0, bg="#1c1830")
        self.label.pack(fill="both", expand=True)
        self.root.geometry(f"{WIDTH}x{self.cur_height}+{int(self.x)}+{int(self.y)}")

        self.tk_image = None

        self.direction = random.choice([-1, 1])
        self.step = 0
        self.blink_state = False
        self.bubble_text = None
        self.dragging = False
        self.was_drag = False
        self.drag_offset = (0, 0)
        self.state = "walk"  # walk | held | thinking | sitting
        self.busy = False
        self.sway = 0.0
        self.sit_win_id = None
        self.behind_mode = False  # true = ela fica sempre atrás das janelas
        self._dismiss_job = None
        self._shape_counter = 0
        self._hidden = False

        # Orientação atual do sprite: frente, lado, diagonal ou costas.
        self.orientation = "frente"
        self._orientation_until = 0
        self._turning = False
        self.sprites = self._load_pixel_sprites()

        self.label.bind("<Button-1>", self.start_drag)
        self.label.bind("<B1-Motion>", self.do_drag)
        self.label.bind("<ButtonRelease-1>", self.stop_drag)
        self.label.bind("<Double-Button-1>", self.open_chat)
        self.label.bind("<Button-3>", self.show_menu)

        self.behind_var = tk.BooleanVar(value=False)

        self.menu = tk.Menu(self.root, tearoff=0)
        self.menu.add_command(label="Perguntar", command=self.ask_menu)
        self.menu.add_command(label="Falar algo", command=self.say_something)
        self.menu.add_command(label="Abrir Claude no navegador", command=self.open_chat)
        self.menu.add_separator()
        self.menu.add_checkbutton(label="Andar atrás das janelas", variable=self.behind_var,
                                   command=self.toggle_behind_mode)
        self.menu.add_command(label="Esquecer conversa", command=self.forget_history)
        self.menu.add_command(label="Fechar", command=self.root.destroy)

        self.render_and_show()
        self.root.after(200, self.tick)
        self.root.after(random.randint(6000, 12000), self.random_speech)
        self.root.after(random.randint(15000, 30000), self.observe_apps)
        self.root.after(random.randint(30000, 60000), self.peekaboo)
        self.root.after(random.randint(20000, 40000), self.maybe_sit)

    # ---------- geometria ----------
    def set_window_height(self, new_height):
        old_bottom = self.y + self.cur_height
        self.cur_height = new_height
        self.y = old_bottom - new_height
        self.root.geometry(f"{WIDTH}x{new_height}+{int(self.x)}+{int(self.y)}")

    # ---------- sprites pixel art ----------
    def _load_pixel_sprites(self):
        """Carrega os quatro ângulos da personagem sem suavizar os pixels."""
        sprites = {}
        names = ("frente", "lado", "diagonal", "costas")
        for name in names:
            path = ASSET_DIR / f"{name}.png"
            try:
                img = Image.open(path).convert("RGBA")
                # Mantém a arte pixelada: NEAREST, nunca LANCZOS.
                img.thumbnail((SPRITE_MAX_W, SPRITE_MAX_H), SPRITE_RESAMPLE)
                sprites[name] = img
            except (OSError, FileNotFoundError):
                sprites[name] = None
                print(f"[bichinho] sprite não encontrado: {path}")

        # Sem frente, usa qualquer sprite disponível para não quebrar o pet.
        fallback = next((v for v in sprites.values() if v is not None), None)
        if fallback is None:
            raise FileNotFoundError(
                f"Nenhum sprite encontrado em {ASSET_DIR}. "
                "Coloque frente.png, lado.png, diagonal.png e costas.png nessa pasta."
            )
        for name in names:
            if sprites[name] is None:
                sprites[name] = fallback.copy()
        return sprites

    def _update_orientation(self):
        """Cria uma pequena sequência de virada para mostrar os quatro ângulos."""
        if self.state == "sitting":
            self.orientation = "frente"
            return

        if self.dragging or self.state == "held":
            self.orientation = "diagonal"
            return

        # Quando começa a andar, mostra lado. Em intervalos curtos ela vira
        # para diagonal/frente/costas, criando uma animação de rotação sem
        # precisar de dezenas de sprites intermediários.
        cycle = self.step % 240
        if cycle < 85:
            self.orientation = "lado"
        elif cycle < 105:
            self.orientation = "diagonal"
        elif cycle < 145:
            self.orientation = "frente"
        elif cycle < 165:
            self.orientation = "diagonal"
        elif cycle < 225:
            self.orientation = "costas"
        else:
            self.orientation = "diagonal"

    def _sprite_for_current_pose(self):
        self._update_orientation()
        sprite = self.sprites[self.orientation].copy()

        # O sprite lateral original olha para a direita. Se ela estiver
        # caminhando para a esquerda, espelhamos horizontalmente.
        if self.orientation in ("lado", "diagonal") and self.direction < 0:
            sprite = sprite.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
        return sprite

    def render_frame(self):
        """Renderiza a personagem usando os sprites pixel art gerados para ela."""
        w, h = WIDTH * SCALE, self.cur_height * SCALE
        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))

        bubble_h = 0
        if self.bubble_text:
            draw = ImageDraw.Draw(img, "RGBA")
            bubble_h = self.draw_bubble(draw, self.bubble_text, w)

        sprite = self._sprite_for_current_pose()
        # Renderiza em alta resolução e volta para o tamanho da janela com
        # NEAREST para conservar os blocos de pixel.
        sprite_big = sprite.resize((sprite.width * SCALE, sprite.height * SCALE), Image.Resampling.NEAREST)

        # Pequeno movimento vertical para dar sensação de vida durante a caminhada.
        bob = 0
        if self.state == "walk" and not self.busy:
            bob = int(abs(math.sin(self.step * 0.18)) * 2 * SCALE)
        elif self.state == "held":
            bob = int(math.sin(self.step * 0.25) * 2 * SCALE)

        x = int((w - sprite_big.width) / 2)
        y = int(h - sprite_big.height - 7 * SCALE - bob)
        if y < bubble_h:
            y = int(bubble_h)

        img.alpha_composite(sprite_big, (x, y))

        # O sprite já contém a sombra de chão; o restante do canvas fica transparente.
        img = img.resize((WIDTH, self.cur_height), Image.Resampling.NEAREST)
        return img

    def capsule_line(self, draw, x1, y1, x2, y2, width, fill):
        r = width / 2
        draw.line([x1, y1, x2, y2], fill=fill, width=int(width))
        draw.ellipse([x1 - r, y1 - r, x1 + r, y1 + r], fill=fill)
        draw.ellipse([x2 - r, y2 - r, x2 + r, y2 + r], fill=fill)

    def draw_bubble(self, draw, text, canvas_w):
        max_text_w = canvas_w - 20 * SCALE
        lines = self._wrap_text(text, max_text_w)
        line_h = FONT_BUBBLE.size + 4 * SCALE
        text_h = line_h * len(lines)
        bubble_h = text_h + 20 * SCALE

        draw.rounded_rectangle([4 * SCALE, 2 * SCALE, canvas_w - 4 * SCALE, bubble_h],
                                radius=12 * SCALE, fill=(255, 255, 255, 235),
                                outline=(210, 195, 180, 255), width=int(1.2 * SCALE))
        cx = canvas_w / 2
        draw.polygon([cx - 8 * SCALE, bubble_h - 2, cx + 8 * SCALE, bubble_h - 2, cx, bubble_h + 10 * SCALE],
                     fill=(255, 255, 255, 235))

        y = 10 * SCALE
        for line in lines:
            wtxt = draw.textlength(line, font=FONT_BUBBLE)
            draw.text((cx - wtxt / 2, y), line, font=FONT_BUBBLE, fill=(50, 40, 30, 255))
            y += line_h
        return bubble_h + 10 * SCALE

    def _wrap_text(self, text, max_w):
        words = text.split()
        lines, cur = [], ""
        dummy = Image.new("RGBA", (1, 1))
        d = ImageDraw.Draw(dummy)
        for word in words:
            trial = (cur + " " + word).strip()
            if d.textlength(trial, font=FONT_BUBBLE) <= max_w:
                cur = trial
            else:
                if cur:
                    lines.append(cur)
                cur = word
        if cur:
            lines.append(cur)
        return lines or [""]

    def render_and_show(self):
        needed_h = self._needed_height()
        if needed_h != self.cur_height:
            self.set_window_height(needed_h)

        frame = self.render_frame()
        self.tk_image = ImageTk.PhotoImage(frame)
        self.label.configure(image=self.tk_image)

        self._shape_counter += 1
        if self._shape_counter % 3 == 0:
            self.root.update_idletasks()
            win_id = self.root.winfo_id()
            ok = self.x11.apply_shape_mask(win_id, frame)
            if self.shape_supported is None:
                self.shape_supported = ok
                if ok:
                    print("[bichinho] transparência real ativada — fundo recortado com sucesso.")
                else:
                    if not self.x11.ok:
                        reason = "python-xlib indisponível"
                    else:
                        reason = self.x11.last_shape_error or "motivo desconhecido"
                    print(f"[bichinho] transparência real NÃO disponível ({reason}); "
                          "usando fundo sólido como alternativa.")
                    self.label.configure(bg="#f4f4f4")

    def _needed_height(self):
        if not self.bubble_text:
            return BASE_HEIGHT
        dummy = Image.new("RGBA", (WIDTH * SCALE, 10))
        d = ImageDraw.Draw(dummy)
        lines = self._wrap_text(self.bubble_text, WIDTH * SCALE - 20 * SCALE)
        line_h = FONT_BUBBLE.size + 4 * SCALE
        bubble_h = (line_h * len(lines) + 20 * SCALE + 10 * SCALE) / SCALE
        return int(BASE_HEIGHT + bubble_h)

    # ---------- laço principal ----------
    def tick(self):
        self.step += 1
        self.blink_state = (self.step % 55 == 0)

        # balanço tipo "carro" enquanto está sendo arrastada
        if self.dragging:
            dx = self.x - self.prev_x
            target_sway = max(-16, min(16, dx * 3.2))
            self.sway += (target_sway - self.sway) * 0.35
        else:
            self.sway += (0 - self.sway) * 0.2
        self.prev_x = self.x

        if self.state == "walk" and not self.dragging and not self.busy:
            self.x += self.direction * 1.6
            if self.x < 0 or self.x > self.screen_w - WIDTH:
                self.direction *= -1
                self.x = max(0, min(self.x, self.screen_w - WIDTH))
            self.root.geometry(f"+{int(self.x)}+{int(self.y)}")

        if self.state == "sitting" and self.sit_win_id is not None:
            if not self.x11.window_exists(self.sit_win_id):
                self._stand_up(random.choice(STAND_CLOSED_LINES))

        if self.behind_mode and self.step % 50 == 0:
            try:
                self.root.lower()
            except tk.TclError:
                pass

        self.render_and_show()
        self.root.after(TICK_MS, self.tick)

    def random_speech(self):
        if not self.busy and not self.is_covered():
            self.show_bubble(random.choice(SPEECH_LINES), duration=3000)
        self.root.after(random.randint(15000, 30000), self.random_speech)

    # ---------- observar apps abertos ----------
    def observe_apps(self):
        if not self.busy and self.x11.ok and self.state != "sitting" and not self.is_covered():
            info = self.x11.get_active_window_info()
            if info:
                klass, name = info
                haystack = f"{klass} {name}".lower()
                comment = None
                for key, options in APP_COMMENTS.items():
                    if key in haystack:
                        comment = random.choice(options)
                        break
                if comment is None and random.random() < 0.4:
                    comment = random.choice(GENERIC_COMMENTS)
                if comment:
                    self.show_bubble(comment, duration=2800)
        self.root.after(random.randint(25000, 50000), self.observe_apps)

    # ---------- modo permanente "atrás das janelas" ----------
    def toggle_behind_mode(self):
        self.behind_mode = self.behind_var.get()
        try:
            if self.behind_mode:
                self.root.attributes("-topmost", False)
                self.root.lower()
            else:
                self._hidden = False
                self.root.attributes("-topmost", True)
                self.root.lift()
        except tk.TclError:
            pass

    def is_covered(self):
        """Ela só é considerada 'coberta' quando não está por cima da pilha
        de janelas (modo atrás das janelas, ou escondida no peekaboo)."""
        if not (self.behind_mode or self._hidden):
            return False
        if not self.x11.ok:
            return False
        my_cx = self.x + WIDTH / 2
        my_cy = self.y + self.cur_height / 2
        for win in self.x11.get_open_windows(exclude_win_id=self.root.winfo_id()):
            if win["x"] <= my_cx <= win["x"] + win["w"] and win["y"] <= my_cy <= win["y"] + win["h"]:
                return True
        return False

    # ---------- sumir atrás das janelas (peekaboo temporário) ----------
    def peekaboo(self):
        if (not self.behind_mode and not self.dragging and not self.busy
                and not self._hidden and self.state != "sitting"):
            self._hidden = True
            try:
                self.root.attributes("-topmost", False)
                self.root.lower()
            except tk.TclError:
                pass
            self.root.after(random.randint(3000, 7000), self._reappear)
        self.root.after(random.randint(40000, 80000), self.peekaboo)

    def _reappear(self):
        self._hidden = False
        try:
            self.root.attributes("-topmost", True)
            self.root.lift()
        except tk.TclError:
            pass
        if not self.busy and random.random() < 0.5:
            self.show_bubble("Cadê eu? Ah, aqui!", duration=2200)

    # ---------- sentar cansada em cima de uma janela ----------
    def maybe_sit(self):
        if (not self.dragging and not self.busy and self.state == "walk"
                and self.x11.ok and random.random() < 0.7):
            windows = self.x11.get_open_windows(exclude_win_id=self.root.winfo_id())
            if windows:
                target = random.choice(windows)
                max_offset = max(target["w"] - WIDTH, 0)
                self.x = target["x"] + random.randint(0, max_offset)
                self.y = target["y"] - BASE_HEIGHT + 20
                self.x = max(0, min(self.x, self.screen_w - WIDTH))
                self.root.geometry(f"+{int(self.x)}+{int(self.y)}")

                self.state = "sitting"
                self.sit_win_id = target["id"]
                self.show_bubble(random.choice(SIT_DOWN_LINES), duration=2500)
                sit_time = random.randint(15000, 35000)
                self.root.after(sit_time, self._sit_timeout)
        self.root.after(random.randint(35000, 70000), self.maybe_sit)

    def _sit_timeout(self):
        if self.state == "sitting":
            self._stand_up(random.choice(STAND_TIMEOUT_LINES))

    def _stand_up(self, line):
        self.state = "walk"
        self.sit_win_id = None
        self.show_bubble(line, duration=2200)

    # ---------- balão de fala ----------
    def show_bubble(self, text, duration=None):
        if self._dismiss_job:
            self.root.after_cancel(self._dismiss_job)
            self._dismiss_job = None
        self.bubble_text = text
        self.busy = True
        if duration is None:
            words = max(len(text.split()), 1)
            duration = min(max(4000, words * 350), 20000)
        if duration < 999999:
            self._dismiss_job = self.root.after(duration, self.hide_bubble)

    def hide_bubble(self):
        self._dismiss_job = None
        self.bubble_text = None
        self.busy = False
        if self.state == "thinking":
            self.state = "walk"

    # ---------- interação com o mouse ----------
    def start_drag(self, event):
        self.dragging = True
        self.was_drag = False
        if self.state == "sitting":
            self.sit_win_id = None
        self.state = "held"
        self.drag_offset = (event.x, event.y)

    def do_drag(self, event):
        self.was_drag = True
        self.x = self.root.winfo_pointerx() - self.drag_offset[0]
        self.y = self.root.winfo_pointery() - self.drag_offset[1]
        self.root.geometry(f"+{int(self.x)}+{int(self.y)}")

    def stop_drag(self, event):
        self.dragging = False
        self.state = "walk"
        if not self.was_drag and self.bubble_text:
            self.hide_bubble()

    def say_something(self):
        self.show_bubble(random.choice(SPEECH_LINES), duration=3000)

    def open_chat(self, event=None):
        webbrowser.open("https://claude.ai/new")

    def show_menu(self, event):
        self.menu.tk_popup(event.x_root, event.y_root)

    def forget_history(self):
        self.history = []
        save_history(self.history)
        self.show_bubble("Memória limpa!", duration=2500)

    # ---------- integração com a IA local ----------
    def ask_menu(self):
        question = simpledialog.askstring("Perguntar", "O que você quer perguntar?", parent=self.root)
        if not question:
            return
        self.history.append({"role": "user", "content": question})
        self.history = self.history[-MAX_HISTORY_MESSAGES:]
        self.state = "thinking"
        self.show_bubble("pensando...", duration=999999)
        threading.Thread(target=self._ask_worker, daemon=True).start()

    def _ask_worker(self):
        answer = ask_local_ai(self.history)
        self.root.after(0, self._show_answer, answer)

    def _show_answer(self, answer):
        self.history.append({"role": "assistant", "content": answer})
        self.history = self.history[-MAX_HISTORY_MESSAGES:]
        save_history(self.history)
        self.state = "walk"
        words = max(len(answer.split()), 1)
        duration = min(max(6000, words * 400), 30000)
        self.show_bubble(answer, duration=duration)

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    try:
        pet = DesktopPet()
        pet.run()
    except Exception as exc:
        try:
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror("Erro no bichinho", str(exc))
        except Exception:
            pass
        raise
